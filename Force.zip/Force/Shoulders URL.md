1. Rear Delt Flies [Разведение задних дельт](https://ferrum-body.ru/razvedenie-ruk-v-trenazhere.html)
2. Cable rear delt fly [Разведение задних дельт на тросе](https://github.com/ShadowOutlook/temporarily/blob/main/exercise/cable%20rear%20delt%20fly.png) [YouTube](https://www.youtube.com/shorts/fbY6Uqc3cI4)
3. Lateral raises [Махи гантелями в стороны](https://builderbody.ru/maxi-gantelyami-v-storony-stoya/?ysclid=lywzzfh1j6608962724)
4. Cable lateral raises [Боковые подъемы в кроссовере](https://www.youtube.com/shorts/rWWuu09kfyY)
5. Seated DB overhead press [Поднятие гантелей / штанги на наклонной скамье](https://www.youtube.com/shorts/kUD87rMSyM4)
6. Cable front raises [Поднятие руки перед собой в кроссовере](https://www.youtube.com/shorts/rWWuu09kfyY)
7. 